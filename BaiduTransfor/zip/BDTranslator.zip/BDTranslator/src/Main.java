import java.util.Scanner;

import com.baidu.translate.demo.TransApi;

public class Main {

    // ��ƽ̨�����APP_ID ��� http://api.fanyi.baidu.com/api/trans/product/desktop?req=developer
    private static final String APP_ID = "20170807000071140";
    private static final String SECURITY_KEY = "uGLl38wagCGsX2eapwJB";

    public static void main(String[] args) {
        TransApi api = new TransApi(APP_ID, SECURITY_KEY);

        //String query = "�߶�600��";
        //System.out.println(api.getTransResult(query, "auto", "en"));
        
        boolean isContinue = true;
        Scanner scan = new Scanner(System.in);
        while (isContinue){            
            System.out.println("�����ַ���");
            String query = scan.nextLine();
            //System.out.print("������ǣ�" + query);
            if(query.startsWith("#q")){
                scan.close();
                isContinue = false;
            }            
            else {
            	if(query != ""){   
            		String result;
            		if(query.startsWith("@"))
            			result = api.getTransResult(query.replace("@", ""), "auto", "zh");
            		else
            			result = api.getTransResult(query, "auto", "en");
                    int site = 0;
                    String[] output = new String[9];
                    for(int i = 0; i <= 8; i++){
                        int start = result.indexOf("\"",site);
                        site = start + 1;
                        int end = result.indexOf("\"",site);
                        site = end + 1;
                        output[i] = result.substring(start + 1, end);
                        //System.out.println(output[i]); 
                    }     
                    System.out.println(output[8]); 
                }       
            }
        }
        scan.close();
    }   

}
